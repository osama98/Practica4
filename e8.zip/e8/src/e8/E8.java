
package e8;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * The program asks the user their personal data and verifies if they are correct.
 * @author Osama and Yassin
 */
public class E8 {

    public static void main(String[] args) {
        E8 run = new E8();
        System.out.println("Introdueix el teu nom i cognom: ");
        run.inputName();
        System.out.println("Introdueix el teu DNI: ");
        run.inputDni();
        System.out.println("Introdueix la teva edat: ");
        run.inputEdad();
        System.out.println("Introdueix el teu pes: ");
        run.inputPes();
        System.out.println("Introdueix el teu sexe: ");
        run.inputSexo();
        System.out.println("Introdueix el teu estat civil: ");
        run.inputEstado();
        System.out.println("Introdueix el teu correo: ");
        run.inputEmail();
        
    }
    /**
     * This module reads the user's name and verifies that there are only letters and spaces.
     * If the name is entered correctly, returns the result, 
     * if the name is not entered correctly it returns an error.
     */
    public void inputName(){
        Scanner lector = new Scanner(System.in);
        //Set the pattern
        Pattern s = Pattern
                .compile("[a-zA-Z]");
        String name = lector.nextLine();
        Matcher t = s.matcher(name);
        if (t.find() == true) {
            System.out.println("Nombre y apellido: "+name);
        } else {
            System.out.println("Error: El nombre y apellido ingresado no es inválido.");
        }
    }
    /**
     * This module reads the user's dni and verifies that there are only 8 numbers and 1 letter.
     * If the dni is entered correctly, returns the result, 
     * if the dni is not entered correctly it returns an error.
     */
    public void inputDni(){
        Scanner lector = new Scanner(System.in); 
        
        //Set the pattern
        Pattern d = Pattern
                .compile("^(([A-Z]\\d{8})|(\\d{8}[A-Z]))$");
        String dni = lector.nextLine();
        
        Matcher l = d.matcher(dni);
        if (l.find() == true) {
            System.out.println("DNI: "+dni);
        } else {
            System.out.println("Error: El DNI ingresado no es inválido.");
        }
        
    }
    /**
     * This module reads the age of the user and verifies if it is between 1 and 100 years old.
     * If the age is entered correctly, returns the result, 
     * if the age is not entered correctly it returns an error.
     */
    public void inputEdad(){
        Scanner lector = new Scanner(System.in); 
        int result=0;
        int edad = lector.nextInt();
        
        if(edad>=1 && edad<=100)
        {
          result= edad; 
          System.out.println("Edad: "+result);
        }
        else
        {
            System.out.println("Error: La edad solo puede estar entre 1 y 100");
        }
    }
    /**
     * This module reads the weight of the user and verifies if it is between 30 and 200 kg.
     * If the weigth is entered correctly, returns the result, 
     * if the weigth is not entered correctly it returns an error.
     */
    public void inputPes(){
        Scanner lector = new Scanner(System.in); 
        double result=0;
        double peso = lector.nextDouble();
        
        if(peso>=30 && peso<=200)
        { 
          result= peso; 
          System.out.println("Peso: "+result);
        }
        else
        {
            System.out.println("Error: El peso solo puede estar entre 30 y 200");
        }
    }
    /**
     * This module reads an option from the menu and verifies if the option is correct.
     * If the option is entered correctly, returns the result, 
     * if the option is not entered correctly it returns an error.
     */
    public void inputSexo(){
        Scanner scan = new Scanner(System.in);
        
        int option;
        //print menu.
        System.out.println("0.Home\n1.Dona");
        System.out.println("Input an option: ");
        option = scan.nextInt();
        String sexo = null;
        //process option.
        switch (option) {
                case 0: System.out.println("Home");
                    sexo = "Home";
                    break;
                case 1: System.out.println("Dona");
                    sexo = "Dona";
                    break;                
                default:
                    break;
            }
        if(option==0||option==1){
        System.out.println("Sexo: "+sexo);
        }
        else{
            System.out.println("Error: Opcion no valida");
        }
    }
    /**
     * This module reads an option from the menu and verifies if the option is correct.
     * If the option is entered correctly, returns the result, 
     * if the option is not entered correctly it returns an error.
     */
    public void inputEstado(){
        Scanner scan = new Scanner(System.in);;
        
        int option;
        //print menu.
        System.out.println("0.Soltero\n1.Casado\n2.Divorciado");
        System.out.println("Input an option: ");
        option = scan.nextInt();
        String estado = null;
        //process option.
        switch (option) {
                case 0: System.out.println("Soltero");
                    estado = "Soltero";
                    break;
                case 1: System.out.println("Casado");
                    estado = "Casado";
                    break;
                case 2: System.out.println("Divorciado");
                    estado = "Divorciado";
                    break;
                default:
                    break;
        }
        if(option==0||option==1||option==2){
        System.out.println("Estado: "+estado);
        }
        else{
            System.out.println("Error: Opcion no valida");
        }
    }
    /**
     * This module reads the user's email and verifies.
     * If the email is entered correctly, returns the result, 
     * if the email is not entered correctly it returns an error.
     */
    public void inputEmail(){
        Scanner lector = new Scanner(System.in); 
        
        // Set the pattern
        Pattern p = Pattern
                .compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
                        + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        String correo = lector.nextLine();
        // Asociar el string al patron
        Matcher m = p.matcher(correo);
        
                
        if (m.find() == true) {
            System.out.println("Correo: "+correo);
        } else {
            System.out.println("Error: El email ingresado no es inválido.");
        }
        
    }
}
       
        