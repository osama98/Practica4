
package pt1.pkg2_ex3;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *This program passes a DNA to RNA sequence and vice versa
 * @author osama
 */
public class ex3 {
        //attributes
    private final String [] menuOptions = {
        "Exit", "Convert ADN to ARN",
        "Convert ARN to ADN",
    };
    
    public static void main(String[] args) {
        ex3 ejecutar = new ex3();
        ejecutar.run();
    }

    private void run() {
        boolean exit = false;  
        do {
            //print menu and get user choice
            int option = showMenuAndReadOption();
            //process option.
            switch (option) {
                case 0: //exit
                    exit = true;
                    break;
                case 1: //ADN to ARN
                    ADNtoARN();
                    break;                
                case 2: //ARN to ADN
                    ARNtoADN();
                    break;  
                default:
                    System.out.println("Wrong option");
                    break;
            }
            
        } while(!exit);
        System.out.println("Exitting application!");      
    }

    /**
     * shows the main menu of the application and reads
     * and option from the user.
     * @return an int with the option selected by user
     * or -1 in case of error.
     */
    private int showMenuAndReadOption() {
        //print menu
        for (int i=0; i<menuOptions.length; i++) {
            System.out.format("%d. %s\n", i, menuOptions[i]);
        }
        int option;
        System.out.print("Input an option: ");
        try {
            Scanner scan = new Scanner(System.in);
            option = scan.nextInt();            
        } catch (InputMismatchException e) {
            option = -1;
        }       
        return option;
    }
    /**
     * This method checks if the DNA sequence is correct and passes it to RNA
     */
    private void ADNtoARN(){
        Scanner lector = new Scanner(System.in); 
        System.out.println("Introdueix una secuencia d'ADN: ");
        String adn = lector.nextLine();
        boolean m = true;
        int i=0;
        String result = "";
        if(adn.length()%3 == 0){
          //check and change
          while(m && (i<adn.length())){
            if ((adn.charAt(i)!='A')&&(adn.charAt(i)!='T')&&(adn.charAt(i)!='C')
                &&(adn.charAt(i)!='G')){
                
                m = false;
            } 
            i++;
            }
          if(m){
             result = adn.replace('T','U'); 
             System.out.println("ARN: "+result);//print RNA sequence
          }
          else{
              System.out.println("ERROR: Has introducido un caracter que no corresponde a un nucleótido");
          }
        }
        else{
            System.out.println("ERROR: La sequencia debe de ser multiplo de 3");
        }
    }
    /**
     * This method checks if the RNA sequence is correct and passes it to DNA
     */
    private void ARNtoADN() {
     Scanner lector = new Scanner(System.in); 
        System.out.println("Introdueix una secuencia d'ARN: ");
        String arn = lector.nextLine();
        boolean m = true;
        int i=0;
        String result = "";
        if(arn.length()%3 == 0){
          //check and change
          while(m && (i<arn.length())){
            if ((arn.charAt(i)!='A')&&(arn.charAt(i)!='U')&&(arn.charAt(i)!='C')
                &&(arn.charAt(i)!='G')){
                
                m = false;
            } 
            i++;
            }
          if(m){
             result = arn.replace('U','T'); 
             System.out.println("ADN: "+result);//print RNA sequence
          }
          else{
              System.out.println("ERROR: Has introducido un caracter que no corresponde a un nucleótido");
          }
        }
        else{
            System.out.println("ERROR: La sequencia debe de ser multiplo de 3");
        }
    }
}
