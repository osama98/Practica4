
package pt1.pkg2_ex1;

import java.util.Scanner;

/**
 * This program asks the user for his name and printed by screen the vowels in uppercase 
 * and the consonants in lowercase and count how many the uppercase and the lowercase.
 * @author osama
 */
public class ex1 {

    public static void main(String[] args) {
        
        ex1 run = new ex1();
        
        System.out.println("Introdueix el teu nom: ");
        
        run.CountAndReplace();
    }
    
     /**
     * This method checks if the characters are vowels or consonants 
     * and prints the modified name.
     */
    public void CountAndReplace(){
        Scanner lector = new Scanner(System.in); 
        String name = lector.nextLine();
        //Variables declaration
        char [] Arraycadena = null;
        int cont=0;
        char caracter;
        //all chars in lowecase
        String change = name.toLowerCase();
        String result="";
        //change vowels
        for(int i=0;i<change.length();i++){
            if ((change.charAt(i)=='a')||(change.charAt(i)=='e')||(change.charAt(i)=='i')
                ||(change.charAt(i)=='o')||(change.charAt(i)=='u')){
                
                result = change.replace('a','A').replace('e','E')
                .replace('i','I').replace('o','O').replace('u','U');
                
                Arraycadena = result.toCharArray();
            }
        }
        //count chars
        for(int i=0;i<Arraycadena.length;i++){
            caracter = Arraycadena[i];
            for(int j=0;j<Arraycadena.length;j++){
                if (Arraycadena[j] == caracter){
                    cont++;
                }
            }
            System.out.println(Arraycadena[i]+" "+ cont);
            cont=0;
        }
        //print result and counters
        System.out.println("Result: " +result);
    }
    
}
